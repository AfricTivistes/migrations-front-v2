	<?php /* 
		Template Name: page.contribution
		Template Post Type: page
		*/
	?>