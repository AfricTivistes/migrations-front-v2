	<?php /* 
		Template Name: page.espace-dialogue
		Template Post Type: page
		*/
	?>