	<?php /* 
		Template Name: page.fact-checking
		Template Post Type: page
		*/
	?>