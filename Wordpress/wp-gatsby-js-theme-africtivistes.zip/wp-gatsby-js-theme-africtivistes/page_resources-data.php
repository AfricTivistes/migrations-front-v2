	<?php /* 
		Template Name: page.resources-data
		Template Post Type: page
		*/
	?>