	<?php /* 
		Template Name: page.contact
		Template Post Type: page
		*/
	?>