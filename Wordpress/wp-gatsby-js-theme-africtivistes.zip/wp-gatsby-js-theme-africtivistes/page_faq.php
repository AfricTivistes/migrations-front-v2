	<?php /* 
		Template Name: page.faq
		Template Post Type: page
		*/
	?>