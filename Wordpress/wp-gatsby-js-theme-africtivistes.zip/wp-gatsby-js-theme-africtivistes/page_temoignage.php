	<?php /* 
		Template Name: page.temoignage
		Template Post Type: page
		*/
	?>